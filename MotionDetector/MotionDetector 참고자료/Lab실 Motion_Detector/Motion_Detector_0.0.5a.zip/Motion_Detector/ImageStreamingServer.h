#pragma once
#include "ImageManager.h"

#define TIMER_FRAME		1000/15	// 15FRMAE�� ms�� ȯ��
#define BUF_SIZE		1024	//�⺻ ����ũ��
#define IMGBUF_SIZE		1024*1024
#define DEFAULT_MODE	TRUE
#define REPLACE_MODE	FALSE

using namespace std;
using namespace cv;

class ImageStreamingServer:public ImageManager
{
public:
	ImageStreamingServer();
	virtual ~ImageStreamingServer();

private:
	ImageManager* pIM;
	CWinThread *mServerThread;
	vector<CWinThread*> mClientThreads;
	vector<SOCKET> mClientSockets;
	SOCKET mServerThreadSock;
	SOCKET mClientThreadSock;
	SOCKADDR_IN mClientAddr;

	UINT mPort;
	char mHostName[100];
	char buf[BUF_SIZE];
	TCHAR *mHostIp;

private:
	static UINT Server_Thread(LPVOID arg);
	static UINT Client_Thread(LPVOID arg);
	void sendImageHeader(SOCKET client_sock, BOOL mode);
	void sendImage(SOCKET client_sock, IplImage *sendImage, BOOL mode);
	void sendResizedImage(SOCKET client_sock, char *fileName, int width, int height);
	void sendMjpeg(SOCKET client_sock, IplImage *sendImage);
	void sendList(SOCKET client_sock);
	CString getImagePath();

public:
	BOOL Start(UINT port);
	BOOL Start();
	void Stop();
};