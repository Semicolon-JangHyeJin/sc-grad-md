#include "stdafx.h"
#include "ImageManager.h"

ImageManager::ImageManager() 
{
	// opencv �� ���� ���� �ʱ�ȭ
	mCapture = NULL;
	currentImage = beforeImage = resultImage = NULL;

	isRunning = FALSE;
}

ImageManager::~ImageManager()
{
	// CAM ���� ���� �� ���ҽ� ���� 
	if( mCapture != NULL ) cvReleaseCapture( &mCapture );
	if( beforeImage != NULL ) cvReleaseImage( &beforeImage );
	if( resultImage != NULL ) cvReleaseImage( &resultImage );
}

BOOL ImageManager::Start()
{
	// CAM ����
	mCapture = cvCaptureFromCAM(0);
	if(mCapture == NULL) {
		AfxMessageBox(L"ī�޶� ������� �ʾҽ��ϴ�.");
		isRunning = FALSE;
	} else {
		// �ʱ�ȭ
		currentImage = cvQueryFrame(mCapture);

		if(beforeImage == NULL && resultImage == NULL) {
			beforeImage = cvCreateImage(cvGetSize(currentImage), 8, 3);
			resultImage = cvCreateImage(cvGetSize(currentImage), 8, 3);
		}

		isRunning = TRUE;
	}

	return isRunning;
}

void ImageManager::Stop()
{
	if( mCapture != NULL ) cvReleaseCapture(&mCapture);

	isRunning = FALSE;
}

void ImageManager::GrabFrame()
{
	if( mCapture != NULL )
		currentImage = cvQueryFrame(mCapture);
}

void ImageManager::CopyCurrentToBefore()
{
	cvCopy(currentImage, beforeImage);
}