#pragma once
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc_c.h>

class ImageManager
{
public:
	ImageManager();
	virtual ~ImageManager();

public:
	CvCapture*	mCapture;
	IplImage*	currentImage;
	IplImage*	beforeImage;
	IplImage*	resultImage;

	BOOL isRunning;

public:
	BOOL Start();
	void Stop();
	void GrabFrame();
	void CopyCurrentToBefore();
};